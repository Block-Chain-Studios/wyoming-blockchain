<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Blog_model extends CI_Model {
  function __construct() {
      parent::__construct();
  }

  //blog select
  public function get_users($user_id = ""){
    if($user_id > 0){
      $this->db->where('user_id', $user_id);
    }
    return $this->db->get('user');
  }

  //blog select
  public function get_blogs($blog_id = ""){
    if($blog_id > 0){
      $this->db->where('id', $blog_id);
    }
    return $this->db->get('blogs');
  }

  public function add_blog(){
    $data['title'] = sanitizer($this->input->post('title'));
    if($this->input->post('actor')){
      $data['actor'] = json_encode($this->input->post('actor'));
    }else{
      $data['actor'] = '[]';
    }
    $data['description'] = $this->input->post('description');
    $data['blog_thumbnail'] = md5(rand()).'.jpg';
    $data['blog_cover'] = md5(rand()).'.jpg';
    $data['status'] = 1;
    $data['added_date'] = strtotime(date('dMY'));
    $this->db->insert('blogs', $data);
    move_uploaded_file($_FILES['blog_thumbnail_image']['tmp_name'], 'assets/global/blog_thumbnails/'.$data['blog_thumbnail']);
    move_uploaded_file($_FILES['blog_cover_image']['tmp_name'], 'assets/global/blog_cover_images/'.$data['blog_cover']);
  }

  public function edit_blog($param1 = ""){
    $data['title'] = sanitizer($this->input->post('title'));
    if($this->input->post('actor')){
      $data['actor'] = json_encode($this->input->post('actor'));
    }else{
      $data['actor'] = '[]';
    }
    $data['description'] = $this->input->post('description');
    $data['blog_thumbnail'] = $this->input->post('blog_thumbnail_name');
    $data['blog_cover'] = $this->input->post('blog_cover_name');
    $data['modified_date'] = strtotime(date('dMY'));
    $this->db->where('id', $param1);
    $this->db->update('blogs', $data);
    move_uploaded_file($_FILES['blog_thumbnail_image']['tmp_name'], 'assets/global/blog_thumbnails/'.$data['blog_thumbnail']);
    move_uploaded_file($_FILES['blog_cover_image']['tmp_name'], 'assets/global/blog_cover_images/'.$data['blog_cover']);
  }

  public function blog_status($param1 = "", $param2 = ""){
    if($param1 == 'active'):
      $data['status'] = 1;
    elseif($param1 == 'inactive'):
      $data['status'] = 0;
    endif;
    $this->db->where('id', $param2);
    $this->db->update('blogs', $data);
  }

  public function delete_blog($param1 = ""){
    $thumbnail_image = $this->db->get_where('blogs', array('id' => $param1))->row('blog_thumbnail');
    $cover_image = $this->db->get_where('blogs', array('id' => $param1))->row('blog_cover');
    unlink('assets/global/blog_thumbnails/'.$thumbnail_image);
    unlink('assets/global/blog_cover_images/'.$cover_image);
    $this->db->where('id', $param1);
    $this->db->delete('blogs');
  }






//*******************************************//
  //blog select
    public function get_blogs_wise_status(){
      $this->db->where('status', 1);
      return $this->db->get('blogs');
    }

    //comment select
    public function get_comments($blog_id = 0, $under_comment_id = 0){
        if($blog_id > 0){
            $this->db->where('blog_id', $blog_id);
        }
        if($under_comment_id > 0){
            $this->db->where('under_comment_id', $under_comment_id);
        }else{
            $this->db->where('under_comment_id', 0);
        }
        return $this->db->get('blog_comments');
    }

    //comment select
    public function get_comment_row($comment_id = 0){
        if($comment_id > 0){
            $this->db->where('id', $comment_id);
        }
        return $this->db->get('blog_comments');
    }

    //blog search
    public function blog_search($searching_key = ""){
      return $this->db->where('status', 1)->like('title', $searching_key, 'both')->or_like('description', $searching_key, 'both')->get('blogs')->result_array();
    }

    public function latest_blog_post(){
      $this->db->order_by('added_date', 'desc');
      $this->db->limit(4);
      $this->db->where('status', 1);
      return $this->db->get('blogs')->result_array();
    }

    public function popular_post(){
      $this->db->order_by('visitor_count', 'desc');
      $this->db->limit(8);
      $this->db->where('status', 1);
      return $this->db->get('blogs')->result_array();
    }

    public function comment_add(){
        $data['blog_id'] = sanitizer($this->input->post('blog_id'));
        $data['comment'] = sanitizer($this->input->post('comment'));
        $data['user_id'] = sanitizer($this->session->userdata('user_id'));
        $data['under_comment_id'] = sanitizer($this->input->post('under_comment_id'));
        $data['added_date'] = strtotime(date('dMY'));
        $this->db->insert('blog_comments', $data);
    }

    public function update_blog_comment($comment_id = ""){
        $data['modified_date'] = strtotime(date('dMY'));
        $data['comment'] = sanitizer($this->input->post('comment'));
        $this->db->where('id', $comment_id);
        $this->db->update('blog_comments', $data);
    }

    function paginate($base_url, $total_rows, $per_page, $uri_segment)
  {
        $config = array('base_url' => $base_url,
            'total_rows' => $total_rows,
            'per_page' => $per_page,
            'uri_segment' => $uri_segment);

        $config['first_link'] = '<i class="fa fa-angle-double-left" aria-hidden="true"></i>';
        $config['first_tag_open'] = '<li style="">';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = '<i class="fa fa-angle-double-right" aria-hidden="true"></i>';
        $config['last_tag_open'] = '<li style="">';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '<i class="fa fa-angle-right" aria-hidden="true"></i>';
        $config['next_tag_open'] = '<li style="">';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '<i class="fa fa-angle-left" aria-hidden="true"></i>';
        $config['prev_tag_open'] = '<li style="">';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active" style=""><a href="#">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li style="">';
        $config['num_tag_close'] = '</li>';
        return $config;
    }
}