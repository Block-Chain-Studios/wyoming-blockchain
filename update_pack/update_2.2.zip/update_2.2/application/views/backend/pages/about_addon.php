<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="panel-title">
                    <?php echo get_phrase('about').' '.$addon['name']; ?>
                </div>
            </div>
            <div class="panel-body" style="padding: 25px;">
                <?php echo $addon['about']; ?>
            </div>
        </div>
    </div>
</div>
