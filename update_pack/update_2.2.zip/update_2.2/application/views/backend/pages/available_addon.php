<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="panel-title">
                    <?php echo get_phrase('available_addons'); ?>
                </div>
            </div>
            <div class="panel-body">
                <iframe scrolling="yes" class="col-md-12 w-100" frameborder="none" style="height: 510px;" src="http://creativeitem.com/demo/neoflex/addon/addon.php"></iframe>
            </div>
        </div>
    </div>
</div>
